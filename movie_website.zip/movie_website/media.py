import webbrowser

class Video():
    """This class stores information common to multiple types of videos, such as movies, video games, tv shows, etc."""
    def __init__(self, video_title, video_tagline, poster_image, trailer_youtube, release_year):
        self.video_title = video_title
        self.video_tagline = video_tagline
        self.poster_image_url = poster_image
        self.trailer_youtube_url = trailer_youtube
        self.release_year = release_year

# movie_id and game_id needed in order to get collapsible panels to work (titles contain spaces and colons so won't work with attribute id)

class Movie(Video):
    """This class stores movie related information."""
    def __init__ (self, video_title, video_tagline, poster_image, trailer_youtube, release_year, movie_id, movie_genre, director):
        Video.__init__(self, video_title, video_tagline, poster_image, trailer_youtube, release_year)
        self.movie_id = movie_id
        self.movie_genre = movie_genre
        self.director = director


class Game(Video):
    """This class stores video game related information."""
    def __init__ (self, video_title, video_tagline, poster_image, trailer_youtube, release_year, game_id, game_genre, studio):
        Video.__init__(self, video_title, video_tagline, poster_image, trailer_youtube, release_year)
        self.game_id = game_id
        self.game_genre = game_genre
        self.studio = studio
