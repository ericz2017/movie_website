import media
import fresh_tomatoes

fury_road = media.Movie("Mad Max: Fury Road",
                        "An average day in Australia",
                        "https://upload.wikimedia.org/wikipedia/en/6/6e/Mad_Max_Fury_Road.jpg",
                        "https://www.youtube.com/watch?v=hEJnMQG9ev8",
                        "2015",
                        "m1",
                        "Action",
                        "George Miller")

lost_in_translation = media.Movie("Lost In Translation",
                                  "More Intensity!",
                                  "https://upload.wikimedia.org/wikipedia/en/4/4c/Lost_in_Translation_poster.jpg",
                                  "https://www.youtube.com/watch?v=W6iVPCRflQM",
                                  "2003",
                                  "m2",
                                  "Romantic Comedy",
                                  "Sofia Coppola",)

fight_club = media.Movie("Fight Club",
                         "The things you own end up owning you",
                         "https://upload.wikimedia.org/wikipedia/en/f/fc/Fight_Club_poster.jpg",
                         "https://www.youtube.com/watch?v=SUXWAEX2jlg",
                         "1999",
                         "m3",
                         "Drama",
                         "David Fincher")

skyrim = media.Game("Skyrim",
                    "Fus Ro Dah!",
                    "https://upload.wikimedia.org/wikipedia/en/1/15/The_Elder_Scrolls_V_Skyrim_cover.png",
                    "https://www.youtube.com/watch?v=QpvM9uwOcUc",
                    "2011",
                    "g1",
                    "Action RPG",
                    "Bethesda Game Studios")

fallout_3 = media.Game("Fallout 3",
                       "War... War never changes",
                       "https://upload.wikimedia.org/wikipedia/en/8/83/Fallout_3_cover_art.PNG",
                       "https://www.youtube.com/watch?v=HjnMIpgUzJ4",
                       "2008",
                       "g2",
                       "Action RPG",
                       "Bethesda Game Studios")

civ2 = media.Game("Civilization II",
                  "eXplore, eXpand, eXploit, and eXterminate",
                  "https://upload.wikimedia.org/wikipedia/en/7/73/Civ2boxart.jpg",
                  "https://www.youtube.com/watch?v=q_13zWWpw7A",
                  "1996",
                  "g3",
                  "Turn-based Strategy",
                  "MicroProse")



movies = [fury_road, lost_in_translation, fight_club]
games = [skyrim, fallout_3, civ2]
fresh_tomatoes.open_page(movies, games)
